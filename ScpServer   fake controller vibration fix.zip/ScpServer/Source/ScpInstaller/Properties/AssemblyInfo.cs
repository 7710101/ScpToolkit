﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScpDriver")]
[assembly: AssemblyProduct("ScpDriver")]

[assembly: Guid("57ba2291-9504-441d-a0fe-9ccdd326508c")]
