﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScpServer")]
[assembly: AssemblyProduct("ScpServer")]

[assembly: Guid("a52b5b20-d9ee-4f32-8518-307fa14aa0c6")]
